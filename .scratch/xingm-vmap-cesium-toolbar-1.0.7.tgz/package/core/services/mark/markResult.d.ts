import { CoordSystem } from '../../mapProviders/coordinates/types';
import { MarkDrawResult, MarkExportItem } from './markTypes';
import * as Cesium from 'cesium';
export declare function buildMarkDrawResult(entity: Cesium.Entity, outputCoordSystem?: CoordSystem): MarkDrawResult | null;
export declare function exportMarkEntity(entity: Cesium.Entity, outputCoordSystem?: CoordSystem): MarkExportItem | null;
