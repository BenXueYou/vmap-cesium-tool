import { MarkDrawType } from './markTypes';
export declare const DEFAULT_MARK_COLORS: Record<MarkDrawType, string>;
