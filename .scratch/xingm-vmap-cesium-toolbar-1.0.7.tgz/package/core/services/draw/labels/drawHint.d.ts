import { Cartesian3, Entity, Viewer } from '../../../../../node_modules/cesium';
import { DrawMode, ResolvedMeasurementLabelStyle } from '../types/drawTypes';
import * as Cesium from 'cesium';
export interface DrawHintTextOptions {
    t?: (key: string) => string;
}
export declare function buildHintText(mode: DrawMode, pointCount: number, options?: DrawHintTextOptions): string;
export declare class DrawHintController {
    private readonly viewer;
    constructor(viewer: Viewer);
    createHintBillboardGraphics(text: string, style: ResolvedMeasurementLabelStyle): Cesium.BillboardGraphics;
    createHintBubbleCanvas(text: string, style: ResolvedMeasurementLabelStyle): HTMLCanvasElement;
    show(position: Cartesian3, text: string, style: ResolvedMeasurementLabelStyle): Entity;
    update(entity: Entity, position: Cartesian3, text: string, style: ResolvedMeasurementLabelStyle): void;
    remove(entity: Entity | null): null;
}
