import { Cartesian3, Viewer } from '../../../../../node_modules/cesium';
import { MeasurementLabelFactory } from '../labels/measurementLabelFactory';
import { DrawArtifacts, DrawMode, ResolvedMeasurementTheme } from '../types/drawTypes';
export declare class DrawEntityFactory {
    private readonly previewFactory;
    private readonly finalFactory;
    constructor(viewer: Viewer, labelFactory: MeasurementLabelFactory);
    createPreview(mode: DrawMode, positions: Cartesian3[], previewPoint: Cartesian3 | undefined, theme: ResolvedMeasurementTheme): import('../../../../../node_modules/cesium').Entity[];
    createFinal(mode: DrawMode, positions: Cartesian3[], theme: ResolvedMeasurementTheme): DrawArtifacts | null;
}
