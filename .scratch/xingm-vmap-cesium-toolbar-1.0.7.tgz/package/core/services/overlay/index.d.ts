/**
 * 覆盖物服务模块入口
 *
 * @packageDocumentation
 */
export { OverlayService } from './OverlayService';
export type { OverlayServiceOptions } from './OverlayService';
