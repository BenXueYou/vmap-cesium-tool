/**
 * 核心模块入口文件
 * 导出所有核心类型、常量和类
 */
export * from './types';
export * from './constants';
export { MapPlugin, createMapPlugin } from './MapPlugin';
import * as Cesium from 'cesium';
export { Cesium };
/**
 * 核心模块版本信息
 */
export declare const VERSION = "1.0.0";
/**
 * 核心模块描述
 */
export declare const DESCRIPTION = "VMap Cesium Tool \u6838\u5FC3\u6A21\u5757 - \u63D0\u4F9B\u5730\u56FE\u63D2\u4EF6\u7684\u57FA\u7840\u7C7B\u578B\u3001\u5E38\u91CF\u548C\u6838\u5FC3\u7C7B";
/**
 * 默认导出核心模块
 */
declare const coreModule: {
    VERSION: string;
    DESCRIPTION: string;
};
export default coreModule;
